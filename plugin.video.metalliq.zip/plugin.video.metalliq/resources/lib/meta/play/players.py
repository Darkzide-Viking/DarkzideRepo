import re
import json
from xbmcswift2 import xbmc, xbmcgui, xbmcvfs
from meta import plugin
from meta.utils.text import to_unicode
from settings import SETTING_AUTO_INSTALL, SETTING_MOVIES_ENABLED_PLAYERS, SETTING_TV_ENABLED_PLAYERS, SETTING_MUSIC_ENABLED_PLAYERS, SETTING_MUSIC_VIDEO_ENABLED_PLAYERS

EXTENSION = ".meta.json"
HTML_TAGS_REGEX = re.compile(r'\[/?(?:color|b|i|u).*?\]', re.I|re.UNICODE)

class AddonPlayer(object):
    def __init__(self, filename, media, meta):
        self.media = media
        self.title = meta["name"]
        self.id = meta.get("id", filename.replace(".meta.json", ""))
        self.clean_title = HTML_TAGS_REGEX.sub('', self.title)
        self.pluginid = meta.get("plugin")
        self.repoid = meta.get("repository")
        self.order = meta.get("priority") or 1000
        self.filters = meta.get("filters", {})
        self.commands = meta.get(media, [])
        self._postprocess = meta.get("postprocess")
    
    def postprocess(self, link):
        code = self._postprocess
        if not code or not isinstance(code, basestring) or "__" in code:
            return link
        link = eval(code, {"__builtins__": {}, "link": link})        
        return link
        
    def absent_repository(self):
        if self.repoid and not xbmc.getCondVisibility('System.HasAddon(%s)' % self.repoid):
            return self.repoid
        return None

    def absent_plugin(self):
        if self.pluginid and not xbmc.getCondVisibility('System.HasAddon(%s)' % self.pluginid):
            return self.pluginid
        return None

    def is_empty(self):
        if self.pluginid and not xbmc.getCondVisibility('System.HasAddon(%s)' % self.pluginid):
            return True
        return not bool(self.commands)
    
def get_players(media, filters = {}):
    assert media in ("tvshows", "movies", "music", "music_video", "live")
    
    players = []
    
    players_path = "special://profile/addon_data/{0}/players/".format(plugin.id)
    files = [x for x in xbmcvfs.listdir(players_path)[1] if x.endswith(EXTENSION)]
    if plugin.get_setting(SETTING_AUTO_INSTALL) == True:
        absent_repositories = []
        absent_plugins  = []
    for file in files:
        path = players_path + file
                    
        try:
            f = xbmcvfs.File(path)
            try:
                content = f.read()
                meta = json.loads(content)
            finally:
                f.close()
            player = AddonPlayer(file, media, meta)
            #if plugin.get_setting(SETTING_AUTO_INSTALL) == True:
            #    if player.absent_repository() != None:
            #        if meta.get("repository") not in absent_repositories: absent_repositories.append(meta.get("repository"))
            #    if player.absent_plugin() != None:
            #        if meta.get("plugin") not in absent_plugins: absent_plugins.append(meta.get("plugin"))
            if not player.is_empty():
                players.append(player)
        except Exception, e:
            plugin.log.error(repr(e))
            msg = "player %s is invalid" % file
            xbmcgui.Dialog().ok('Invalid player', msg)
            raise
    #print "QQQQ"+str(absent_repositories)
    #print "QQQQ"+str(absent_plugins)
    #if len(absent_repositories) > 0 and plugin.get_setting(SETTING_AUTO_INSTALL) == True:
    #    for item in absent_repositories:
    #        install_absent(item)
    #        xbmc.sleep(500)
    #        while xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):
    #            count = count + 1
    #            countdown = 30 - count
    #            xbmc.sleep(1000)
    #            if xbmc.getCondVisibility('Window.IsVisible(yesnodialog)') or count >= 30:
    #                break
    #            xbmc.executebuiltin("Notification(Install %s?,Time-Out: %s Seconds)" % (item, countdown))
    return sort_players(players, filters)

def backupfunction():
    xbmc.executebuiltin("Notification(Updating Repositories,Please Wait)")
    new_repositories = []
    blacklisted_repositories = []
    if len(absent_repositories) > 0 and plugin.get_setting(SETTING_AUTO_INSTALL) == True:
        for item in absent_repositories:
            if installed(item) == True:
                new_repositories.append(item)
            else:
                blacklisted_repositories.append(item)
    if len(new_repositories) > 0 and plugin.get_setting(SETTING_AUTO_INSTALL) == True:
        for item in absent_repositories:
            if item not in new_repositories:
                if installed(item) != True:
                    blacklisted_repositories.append(item)
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")
    xbmc.executebuiltin("Notification(Refreshing Repositories,Please Wait,10000)")
    xbmc.sleep(10000)
    if plugin.get_setting(SETTING_AUTO_INSTALL) == True:
        new_plugins = []
        blacklisted_plugins  = []
    if len(absent_plugins) > 0 and plugin.get_setting(SETTING_AUTO_INSTALL) == True:
        for item in absent_plugins:
            install_absent(item)
            xbmc.sleep(500)
            while xbmc.getCondVisibility('Window.IsVisible(yesnodialog)'):
                count = count + 1
                countdown = 30 - count
                xbmc.sleep(1000)
                if xbmc.getCondVisibility('Window.IsVisible(yesnodialog)') or count >= 30:
                    break
                xbmc.executebuiltin("Notification(Install %s?,Time-Out: %s Seconds)" % (item, countdown))
        for item in absent_plugins:
            if installed(item) == True:
                new_plugins.append(item)
            else:
                blacklisted_plugins.append(item)

def sort_players(players, filters = {}):
    result = []
    for player in players:
        filtered = False
        checked = False
        for filter_key, filter_value in filters.items():    
            value = player.filters.get(filter_key)
            if value:
                checked = True
                if to_unicode(value) != to_unicode(filter_value):
                    filtered = True
        
        if not filtered:
            needs_browsing = False
            for command_group in player.commands:
                for command in command_group:
                    if command.get('steps'):
                        needs_browsing = True
                        break
            
            result.append((not checked, needs_browsing, player.order, player.clean_title.lower(), player))
    
    result.sort()
    return [x[-1] for x in result]
    
def get_needed_langs(players):
    languages = set()
    for player in players:
        for command_group in player.commands:  
            for command in command_group:
                command_lang = command.get("language", "en")
                languages.add(command_lang)
    return languages
            

def install_absent(item):
    xbmc.executebuiltin("Notification(Install,%s?)" % item)
    xbmc.executebuiltin('ActivateWindow(addonbrowser,plugin://%s/?)' % item)
    xbmc.executebuiltin("UpdateLocalAddons")
    xbmc.executebuiltin("UpdateAddonRepos")

def installed(item):
    if xbmc.getCondVisibility('System.HasAddon(%s)' % item):
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("UpdateAddonRepos")
        xbmc.sleep(1000)
        while xbmc.getInfoLabel('System.AddonVersion(%s)' % item) == "0.0.0.1":
            xbmc.sleep(1000)
        return True
    else: return False

def install_absent_shit(pluginid):
    if len(absent_repositories) > 0 and plugin.get_setting(SETTING_AUTO_INSTALL) == True:
        for item in absent_repositories:
            xbmc.executebuiltin('ActivateWindow(10025,plugin://%s/?)' % item)
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("UpdateAddonRepos")
        xbmc.executebuiltin("Notification(UpdateAddonRepos,test2)")
        count = 0
        while count <= 15:
            countdown = 15 - count
            if count == 0:
                xbmc.executebuiltin("Notification(Choose Repository's,To Install)")
            else:
                xbmc.executebuiltin("Notification(Updating Repository's,Please Wait: %s seconds)" % countdown)
            xbmc.sleep(1000)
            count = count + 1
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("UpdateAddonRepos")
        xbmc.executebuiltin("Notification(UpdateAddonRepos,test3)")
        new_repositories = []
        blacklist_repositories = []
        for item in absent_repositories:
            if xbmc.getCondVisibility('System.HasAddon(%s)' % item): new_repositories.append(item)
            else: blacklist_repositories.append(item)
        if len(new_repositories) > 0:
            xbmc.executebuiltin("UpdateLocalAddons")
            xbmc.executebuiltin("UpdateAddonRepos")
            xbmc.executebuiltin("Notification(UpdateAddonRepos,test4)")
            while count <= 30:
                countdown = 30 - count
                xbmc.executebuiltin("Notification(Refreshing Repository's,Please Wait: %s seconds)" % countdown)
                xbmc.sleep(1000)
                count = count + 1
    if len(absent_plugins) > 0 and plugin.get_setting(SETTING_AUTO_INSTALL) == True:
        for item in absent_plugins:
            xbmc.executebuiltin('ActivateWindow(10025,plugin://%s/?)' % item)
            while not xbmc.getCondVisibility('Window.Previous(yesnodialog)'):
                xbmc.sleep(1000)
                count = count + 1
                countdown = 30 - count
                xbmc.executebuiltin("Notification(Checking: %s,Time-Out: %s Seconds)" % (item, countdown))
                if countdown <= 0 or xbmc.getCondVisibility('Window.Previous(yesnodialog)'):
                    break
        xbmc.executebuiltin("UpdateLocalAddons")
        xbmc.executebuiltin("UpdateAddonRepos")
        xbmc.executebuiltin("Notification(UpdateAddonRepos,test5)")
        count = 0
        while count <= 30:
            countdown = 30 - count
            xbmc.executebuiltin("Notification(Updating plugin's,Please Wait: %s seconds)" % countdown)
            xbmc.sleep(1000)
            count = count + 1

ADDON_SELECTOR = AddonPlayer("selector", "any", meta={"name": "Selector"})
ADDON_DEFAULT = AddonPlayer("default", "any", meta={"name": "Default"})
